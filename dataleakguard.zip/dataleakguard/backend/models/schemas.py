from pydantic import BaseModel
from typing import List, Optional


class DetectedEntity(BaseModel):
    entity_type: str
    value: str
    start: int
    end: int
    score: float
    risk: str


class ScanRequest(BaseModel):
    prompt: str


class ScanResponse(BaseModel):
    detected: List[DetectedEntity]
    risk_score: int
    analysis_stage: str


class HealthResponse(BaseModel):
    status: str
    service: str

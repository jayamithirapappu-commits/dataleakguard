"""
Purpose classification module for DataLeakGuard.

This module defines the canonical purpose labels that Gemma 4 should classify user prompts into.
It provides validation, normalization, and helper functions for purpose handling.

Security Note: This module does NOT make privacy decisions. It only defines and validates
purpose labels. Privacy decisions are made by the risk engine (risk_engine.py).
"""

from typing import List, Literal, Optional
from dataclasses import dataclass
from enum import Enum


# Canonical purpose labels - exactly six supported purposes
# These are the ONLY purpose values that should be returned by Gemma
PURPOSE_RESUME_IMPROVEMENT = "resume_improvement"
PURPOSE_CODE_DEBUGGING = "code_debugging"
PURPOSE_MEDICAL_SUMMARIZATION = "medical_summarization"
PURPOSE_DOCUMENT_ANALYSIS = "document_analysis"
PURPOSE_EMAIL_WRITING = "email_writing"
PURPOSE_GENERAL_QUESTION = "general_question"

# Fallback purpose for unknown or invalid classifications
PURPOSE_FALLBACK = PURPOSE_GENERAL_QUESTION


class Purpose(str, Enum):
    """Enum of supported purpose labels."""
    
    RESUME_IMPROVEMENT = PURPOSE_RESUME_IMPROVEMENT
    CODE_DEBUGGING = PURPOSE_CODE_DEBUGGING
    MEDICAL_SUMMARIZATION = PURPOSE_MEDICAL_SUMMARIZATION
    DOCUMENT_ANALYSIS = PURPOSE_DOCUMENT_ANALYSIS
    EMAIL_WRITING = PURPOSE_EMAIL_WRITING
    GENERAL_QUESTION = PURPOSE_GENERAL_QUESTION


# List of all supported purposes for validation
SUPPORTED_PURPOSES: List[str] = [
    PURPOSE_RESUME_IMPROVEMENT,
    PURPOSE_CODE_DEBUGGING,
    PURPOSE_MEDICAL_SUMMARIZATION,
    PURPOSE_DOCUMENT_ANALYSIS,
    PURPOSE_EMAIL_WRITING,
    PURPOSE_GENERAL_QUESTION,
]


@dataclass
class PurposeResult:
    """
    Structured result from purpose classification.
    
    Attributes:
        purpose: The canonical purpose label
        confidence: Confidence score between 0.0 and 1.0
    """
    purpose: str
    confidence: float
    
    def __post_init__(self):
        """Validate the result after initialization."""
        # Normalize purpose
        self.purpose = normalize_purpose(self.purpose)
        
        # Validate and clamp confidence
        if not isinstance(self.confidence, (int, float)):
            self.confidence = 0.0
        self.confidence = max(0.0, min(1.0, float(self.confidence)))


def is_valid_purpose(purpose: str) -> bool:
    """
    Check if a purpose string is valid (belongs to supported purposes).
    
    Args:
        purpose: The purpose string to validate
        
    Returns:
        True if purpose is valid, False otherwise
    """
    return purpose in SUPPORTED_PURPOSES


def normalize_purpose(purpose: str) -> str:
    """
    Normalize a purpose string to a canonical label.
    
    If the purpose is not recognized, falls back to general_question.
    
    Args:
        purpose: The purpose string to normalize
        
    Returns:
        A canonical purpose label from SUPPORTED_PURPOSES
    """
    if not purpose or not isinstance(purpose, str):
        return PURPOSE_FALLBACK
    
    # Strip whitespace and convert to lowercase for comparison
    purpose_normalized = purpose.strip().lower()
    
    # Direct match
    if purpose_normalized in SUPPORTED_PURPOSES:
        return purpose_normalized
    
    # Fuzzy matching for common variations
    purpose_mapping = {
        "resume": PURPOSE_RESUME_IMPROVEMENT,
        "cv": PURPOSE_RESUME_IMPROVEMENT,
        "debug": PURPOSE_CODE_DEBUGGING,
        "debugging": PURPOSE_CODE_DEBUGGING,
        "fix bug": PURPOSE_CODE_DEBUGGING,
        "medical": PURPOSE_MEDICAL_SUMMARIZATION,
        "summarize": PURPOSE_MEDICAL_SUMMARIZATION,
        "summarization": PURPOSE_MEDICAL_SUMMARIZATION,
        "document": PURPOSE_DOCUMENT_ANALYSIS,
        "analyze": PURPOSE_DOCUMENT_ANALYSIS,
        "email": PURPOSE_EMAIL_WRITING,
        "write email": PURPOSE_EMAIL_WRITING,
        "general": PURPOSE_GENERAL_QUESTION,
        "question": PURPOSE_GENERAL_QUESTION,
        "other": PURPOSE_GENERAL_QUESTION,
    }
    
    for key, value in purpose_mapping.items():
        if key in purpose_normalized:
            return value
    
    # Unknown purpose - fallback
    return PURPOSE_FALLBACK


def validate_confidence(confidence: float) -> bool:
    """
    Validate that a confidence score is between 0 and 1.
    
    Args:
        confidence: The confidence score to validate
        
    Returns:
        True if confidence is valid, False otherwise
    """
    if not isinstance(confidence, (int, float)):
        return False
    return 0.0 <= float(confidence) <= 1.0


def get_purpose_description(purpose: str) -> str:
    """
    Get a human-readable description for a purpose.
    
    Args:
        purpose: The purpose label
        
    Returns:
        Human-readable description
    """
    descriptions = {
        PURPOSE_RESUME_IMPROVEMENT: "Improving or refining a resume/CV",
        PURPOSE_CODE_DEBUGGING: "Debugging or fixing code issues",
        PURPOSE_MEDICAL_SUMMARIZATION: "Summarizing medical documents or health records",
        PURPOSE_DOCUMENT_ANALYSIS: "Analyzing or reviewing documents",
        PURPOSE_EMAIL_WRITING: "Writing or composing emails",
        PURPOSE_GENERAL_QUESTION: "General questions or other tasks",
    }
    
    return descriptions.get(purpose, "Unknown purpose")


def construct_classification_prompt(user_prompt: str) -> str:
    """
    Construct the system prompt for Gemma 4 purpose classification.
    
    This prompt instructs Gemma to:
    - Classify the user's intended task
    - Return only valid JSON
    - Use only supported purpose labels
    - NOT make privacy decisions
    - Return confidence between 0 and 1
    
    Args:
        user_prompt: The user's prompt to classify
        
    Returns:
        The complete prompt for Gemma
    """
    system_instruction = """You are the purpose-classification component of a privacy firewall.

Your ONLY task is to classify the user's intended task into one of these categories:
- resume_improvement
- code_debugging
- medical_summarization
- document_analysis
- email_writing
- general_question

Return ONLY valid JSON in this exact format:
{
"purpose": "<category>",
"confidence": <number between 0 and 1>
}

Rules:
- Do not return explanations
- Do not return Markdown
- Do not return code fences
- Do NOT make privacy decisions (that is handled by another component)
- Classify based on the user's actual requested task, not merely the presence of sensitive data
- If uncertain, use general_question
- Confidence must be between 0 and 1

Examples:"""

    few_shot_examples = """
User: "Improve my resume and make my project descriptions stronger."
Output: {"purpose": "resume_improvement", "confidence": 0.98}

User: "My Python code gives a KeyError. Find the bug."
Output: {"purpose": "code_debugging", "confidence": 0.98}

User: "Summarize this medical report into simple language."
Output: {"purpose": "medical_summarization", "confidence": 0.98}

User: "Read this contract and explain the important sections."
Output: {"purpose": "document_analysis", "confidence": 0.95}

User: "Write a professional email to my HR manager."
Output: {"purpose": "email_writing", "confidence": 0.98}

User: "What is the difference between Python lists and tuples?"
Output: {"purpose": "general_question", "confidence": 0.98}
"""

    user_section = f'\nUser: "{user_prompt}"\nOutput:'

    return f"{system_instruction}\n{few_shot_examples}{user_section}"

"""
Gemma 4 purpose classification client for DataLeakGuard.

This module handles communication with Gemma 4 for purpose classification.
It uses the OpenAI Python SDK as a client interface for OpenAI-compatible endpoints.

Security Note:
- This module does NOT make privacy decisions
- It only classifies the user's intended task
- Privacy decisions are made by the risk engine (risk_engine.py)
- No sensitive information is logged or printed
- API keys are loaded from environment variables only
"""

import os
import json
import re
import logging
from typing import Optional
from openai import OpenAI, APIError, APITimeoutError, RateLimitError

from backend.core.purpose import (
    PurposeResult,
    is_valid_purpose,
    normalize_purpose,
    validate_confidence,
    PURPOSE_FALLBACK,
    construct_classification_prompt,
)

# Configure logging - DO NOT log sensitive information
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class GemmaPurposeClassifier:
    """
    Client for Gemma 4 purpose classification.
    
    This class handles:
    - Model initialization and configuration
    - Sending classification requests to Gemma
    - Parsing and validating model responses
    - Error handling and safe fallback
    """
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        model: Optional[str] = None,
        base_url: Optional[str] = None,
    ):
        """
        Initialize the Gemma purpose classifier.
        
        Args:
            api_key: Gemma API key (if None, loads from GEMMA_API_KEY env var)
            model: Model name (if None, loads from GEMMA_MODEL env var, defaults to gemma-4-31b-it)
            base_url: API endpoint URL (if None, loads from GEMMA_BASE_URL env var)
        
        Raises:
            ValueError: If API key is not provided and not found in environment
        """
        # Load configuration from environment variables if not provided
        self.api_key = api_key or os.getenv("GEMMA_API_KEY")
        self.model = model or os.getenv("GEMMA_MODEL", "gemma-4-31b-it")
        self.base_url = base_url or os.getenv("GEMMA_BASE_URL")
        
        # Validate API key
        if not self.api_key:
            raise ValueError(
                "GEMMA_API_KEY environment variable or api_key parameter is required. "
                "Please set the API key before using GemmaPurposeClassifier."
            )
        
        # Initialize OpenAI client (for OpenAI-compatible endpoints)
        # This allows using Gemma through providers that offer OpenAI-compatible APIs
        try:
            self.client = OpenAI(
                api_key=self.api_key,
                base_url=self.base_url,
            )
            logger.info("Gemma client initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize Gemma client: {e}")
            raise
    
    def classify(self, prompt: str) -> PurposeResult:
        """
        Classify the purpose of a user prompt using Gemma 4.
        
        Args:
            prompt: The user's prompt to classify
            
        Returns:
            PurposeResult with purpose label and confidence score
            
        Note:
            If classification fails, returns a safe fallback (general_question, confidence=0.0)
            Logs errors WITHOUT exposing sensitive prompt contents
        """
        if not prompt or not isinstance(prompt, str):
            logger.warning("Empty or invalid prompt provided")
            return PurposeResult(purpose=PURPOSE_FALLBACK, confidence=0.0)
        
        # Construct the classification prompt
        classification_prompt = construct_classification_prompt(prompt)
        
        try:
            # Call Gemma 4
            logger.info("Sending purpose classification request to Gemma")
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "user", "content": classification_prompt}
                ],
                temperature=0.3,  # Low temperature for consistent classification
                max_tokens=100,   # Short response for JSON output
            )
            
            # Extract response text
            response_text = response.choices[0].message.content.strip()
            logger.info("Gemma classification response received")
            
            # Parse and validate the response
            result = self._parse_response(response_text)
            
            return result
            
        except APITimeoutError as e:
            logger.error(f"Gemma API timeout: {e}")
            return PurposeResult(purpose=PURPOSE_FALLBACK, confidence=0.0)
            
        except RateLimitError as e:
            logger.error(f"Gemma API rate limit exceeded: {e}")
            return PurposeResult(purpose=PURPOSE_FALLBACK, confidence=0.0)
            
        except APIError as e:
            logger.error(f"Gemma API error: {e}")
            return PurposeResult(purpose=PURPOSE_FALLBACK, confidence=0.0)
            
        except Exception as e:
            logger.error(f"Unexpected error during Gemma classification: {e}")
            return PurposeResult(purpose=PURPOSE_FALLBACK, confidence=0.0)
    
    def _parse_response(self, response_text: str) -> PurposeResult:
        """
        Parse and validate Gemma's response.
        
        Handles various response formats:
        - Pure JSON
        - JSON with surrounding text
        - JSON in code fences
        
        Args:
            response_text: The raw response text from Gemma
            
        Returns:
            Validated PurposeResult
            
        Note:
            If parsing fails or validation fails, returns safe fallback
        """
        try:
            # Try to extract JSON from response
            json_str = self._extract_json(response_text)
            
            # Parse JSON
            data = json.loads(json_str)
            
            # Extract purpose and confidence
            purpose = data.get("purpose", "")
            confidence = data.get("confidence", 0.0)
            
            # Validate purpose
            if not is_valid_purpose(purpose):
                logger.warning(f"Invalid purpose '{purpose}' from Gemma, normalizing")
                purpose = normalize_purpose(purpose)
            
            # Validate confidence
            if not validate_confidence(confidence):
                logger.warning(f"Invalid confidence {confidence} from Gemma, using fallback")
                confidence = 0.0
            
            result = PurposeResult(purpose=purpose, confidence=confidence)
            logger.info(f"Purpose classification successful: {purpose} (confidence: {confidence})")
            
            return result
            
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse JSON from Gemma response: {e}")
            return PurposeResult(purpose=PURPOSE_FALLBACK, confidence=0.0)
            
        except Exception as e:
            logger.error(f"Error parsing Gemma response: {e}")
            return PurposeResult(purpose=PURPOSE_FALLBACK, confidence=0.0)
    
    def _extract_json(self, text: str) -> str:
        """
        Extract JSON from response text.
        
        Handles:
        - Pure JSON
        - JSON with surrounding text
        - JSON in code fences (```json ... ```)
        
        Args:
            text: The response text
            
        Returns:
            Extracted JSON string
            
        Raises:
            ValueError: If JSON cannot be extracted
        """
        # Try to find JSON in code fences
        code_fence_pattern = r'```(?:json)?\s*(\{.*?\})\s*```'
        match = re.search(code_fence_pattern, text, re.DOTALL)
        if match:
            return match.group(1)
        
        # Try to find JSON object in the text
        json_pattern = r'\{[^{}]*"[^"]+"\s*:\s*[^{}]+\}'
        match = re.search(json_pattern, text, re.DOTALL)
        if match:
            return match.group(0)
        
        # If the entire text looks like JSON, return it
        text_stripped = text.strip()
        if text_stripped.startswith('{') and text_stripped.endswith('}'):
            return text_stripped
        
        # If nothing works, raise error
        raise ValueError("Could not extract JSON from response")


def get_classifier() -> GemmaPurposeClassifier:
    """
    Factory function to create a GemmaPurposeClassifier instance.
    
    This function loads configuration from environment variables and creates
    a classifier instance. Useful for dependency injection in FastAPI.
    
    Returns:
        Configured GemmaPurposeClassifier instance
        
    Raises:
        ValueError: If required environment variables are not set
    """
    return GemmaPurposeClassifier()

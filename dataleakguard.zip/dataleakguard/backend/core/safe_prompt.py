from typing import List, Dict


def generate_safe_prompt(original_prompt: str, decisions: List[Dict]) -> str:
    """
    Generate a safe prompt by replacing sensitive values based on privacy decisions.
    
    This function processes decisions in reverse character-offset order to ensure
    that replacing one entity does not corrupt the positions of other entities.
    
    Args:
        original_prompt: The original user prompt
        decisions: List of privacy decisions from the risk engine.
                  Each decision has: entity_type, value, decision, reason
    
    Returns:
        A safe prompt with sensitive values replaced according to decisions
    
    Example:
        >>> original = "Improve my resume. My name is John. My phone is 9876543210."
        >>> decisions = [
        ...     {"entity_type": "PERSON", "value": "John", "decision": "KEEP", "reason": "..."},
        ...     {"entity_type": "PHONE_NUMBER", "value": "9876543210", "decision": "REDACT", "reason": "..."}
        ... ]
        >>> generate_safe_prompt(original, decisions)
        "Improve my resume. My name is John. My phone is [PHONE_NUMBER REDACTED]."
    """
    # If no decisions, return original prompt unchanged
    if not decisions:
        return original_prompt
    
    # Convert prompt to list for easier manipulation
    prompt_chars = list(original_prompt)
    
    # Sort decisions by start position in descending order
    # This ensures that replacing later entities doesn't affect earlier positions
    sorted_decisions = sorted(decisions, key=lambda d: d.get("start", 0), reverse=True)
    
    for decision in sorted_decisions:
        entity_type = decision["entity_type"]
        value = decision["value"]
        decision_type = decision["decision"]
        
        # If decision is KEEP, leave the value unchanged
        if decision_type == "KEEP":
            continue
        
        # Find the position of the value in the original prompt
        # Use the stored start/end positions if available
        start = decision.get("start")
        end = decision.get("end")
        
        # If start/end not provided, search for the value
        if start is None or end is None:
            # Find the last occurrence of the value (since we're processing in reverse)
            # This handles cases where the same value appears multiple times
            value_str = str(value)
            start = original_prompt.rfind(value_str)
            if start == -1:
                # Value not found, skip this decision
                continue
            end = start + len(value_str)
        
        # Generate replacement text based on decision type
        replacement = _get_replacement(entity_type, decision_type)
        
        # Replace the value in the prompt
        # Since we're processing in reverse order, positions are still valid
        prompt_chars[start:end] = list(replacement)
    
    # Convert back to string
    safe_prompt = "".join(prompt_chars)
    
    return safe_prompt


def _get_replacement(entity_type: str, decision: str) -> str:
    """
    Get the replacement text for an entity based on the decision.
    
    Args:
        entity_type: The type of entity (e.g., "PERSON", "EMAIL_ADDRESS")
        decision: The decision (OPTIONAL, REDACT, BLOCK)
    
    Returns:
        The replacement text to use
    """
    if decision == "OPTIONAL":
        return f"[{entity_type} REMOVED - OPTIONAL]"
    
    elif decision == "REDACT":
        return f"[{entity_type} REDACTED]"
    
    elif decision == "BLOCK":
        return f"[{entity_type} BLOCKED]"
    
    else:
        # Unknown decision type
        return f"[{entity_type} {decision.upper()}]"

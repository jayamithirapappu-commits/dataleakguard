from typing import List, Dict, Literal


# Supported decision types
Decision = Literal["KEEP", "OPTIONAL", "REDACT", "BLOCK"]


# Privacy rules for each entity type and purpose combination
# Format: {purpose: {entity_type: decision}}
PRIVACY_RULES = {
    "resume_improvement": {
        "PERSON": "KEEP",
        "EMAIL_ADDRESS": "OPTIONAL",
        "PHONE_NUMBER": "REDACT",
        "CREDIT_CARD": "REDACT",
        "AADHAAR_NUMBER": "REDACT",
        "API_KEY": "REDACT",
        "PASSWORD": "REDACT",
    },
    "code_debugging": {
        "PERSON": "OPTIONAL",
        "EMAIL_ADDRESS": "REDACT",
        "PHONE_NUMBER": "REDACT",
        "CREDIT_CARD": "REDACT",
        "AADHAAR_NUMBER": "REDACT",
        "API_KEY": "REDACT",
        "PASSWORD": "REDACT",
    },
    "medical_summarization": {
        "PERSON": "OPTIONAL",
        "EMAIL_ADDRESS": "REDACT",
        "PHONE_NUMBER": "REDACT",
        "CREDIT_CARD": "REDACT",
        "AADHAAR_NUMBER": "REDACT",
        "API_KEY": "REDACT",
        "PASSWORD": "REDACT",
    },
    "document_analysis": {
        "PERSON": "KEEP",
        "EMAIL_ADDRESS": "OPTIONAL",
        "PHONE_NUMBER": "REDACT",
        "CREDIT_CARD": "REDACT",
        "AADHAAR_NUMBER": "REDACT",
        "API_KEY": "REDACT",
        "PASSWORD": "REDACT",
    },
    "email_writing": {
        "PERSON": "KEEP",
        "EMAIL_ADDRESS": "OPTIONAL",
        "PHONE_NUMBER": "REDACT",
        "CREDIT_CARD": "REDACT",
        "AADHAAR_NUMBER": "REDACT",
        "API_KEY": "REDACT",
        "PASSWORD": "REDACT",
    },
    "general_question": {
        "PERSON": "OPTIONAL",
        "EMAIL_ADDRESS": "REDACT",
        "PHONE_NUMBER": "REDACT",
        "CREDIT_CARD": "REDACT",
        "AADHAAR_NUMBER": "REDACT",
        "API_KEY": "REDACT",
        "PASSWORD": "REDACT",
    },
}


# Reasoning for each decision based on entity type and purpose
REASONING_TEMPLATES = {
    ("PERSON", "KEEP", "resume_improvement"): "Person name is relevant to resume improvement.",
    ("PERSON", "KEEP", "email_writing"): "Person name is relevant for email writing.",
    ("PERSON", "KEEP", "document_analysis"): "Person name is relevant to document analysis.",
    ("PERSON", "OPTIONAL", None): "Person name is optional for this purpose.",
    ("PERSON", "REDACT", None): "Person name is redacted for privacy protection.",
    
    ("EMAIL_ADDRESS", "OPTIONAL", None): "Email address is optional for this purpose.",
    ("EMAIL_ADDRESS", "REDACT", None): "Email address is sensitive and redacted for privacy.",
    
    ("PHONE_NUMBER", "REDACT", None): "Phone number is sensitive and redacted for privacy.",
    
    ("CREDIT_CARD", "REDACT", None): "Credit card number is highly sensitive and always redacted.",
    
    ("AADHAAR_NUMBER", "REDACT", None): "Aadhaar number is highly sensitive and always redacted.",
    
    ("API_KEY", "REDACT", None): "API key is a credential and always redacted.",
    
    ("PASSWORD", "REDACT", None): "Password is a credential and always redacted.",
}


def evaluate_privacy(detected_entities: List[Dict], purpose: str) -> List[Dict]:
    """
    Evaluate privacy decisions for detected entities based on the user's purpose.
    
    This function is deterministic and rule-based. It does NOT use any LLM or external AI.
    
    Args:
        detected_entities: List of detected entities from the sensitive data detector.
                          Each entity has: entity_type, value, start, end, score, risk
        purpose: The user's purpose for using the AI (e.g., "resume_improvement", "code_debugging")
    
    Returns:
        List of decisions with entity_type, value, decision, and reason
    
    Example:
        >>> entities = [
        ...     {"entity_type": "PERSON", "value": "John", "start": 10, "end": 14, "score": 0.95, "risk": "LOW"},
        ...     {"entity_type": "PHONE_NUMBER", "value": "9876543210", "start": 25, "end": 35, "score": 0.9, "risk": "HIGH"}
        ... ]
        >>> evaluate_privacy(entities, "resume_improvement")
        [
            {"entity_type": "PERSON", "value": "John", "decision": "KEEP", 
             "reason": "Person name is relevant to resume improvement."},
            {"entity_type": "PHONE_NUMBER", "value": "9876543210", "decision": "REDACT",
             "reason": "Phone number is sensitive and redacted for privacy."}
        ]
    """
    decisions = []
    
    # Get rules for the specified purpose, default to general_question if not found
    purpose_rules = PRIVACY_RULES.get(purpose, PRIVACY_RULES["general_question"])
    
    for entity in detected_entities:
        entity_type = entity["entity_type"]
        value = entity["value"]
        start = entity.get("start")
        end = entity.get("end")
        risk = entity.get("risk", "MEDIUM")
        
        # Get the base decision from rules
        base_decision = purpose_rules.get(entity_type, "REDACT")
        
        # CRITICAL SAFETY RULE: Never KEEP entities with CRITICAL risk
        if risk == "CRITICAL":
            decision = "REDACT"
        else:
            decision = base_decision
        
        # Generate reasoning
        reason = _get_reasoning(entity_type, decision, purpose)
        
        decision_entry = {
            "entity_type": entity_type,
            "value": value,
            "decision": decision,
            "reason": reason,
        }
        
        # Include start/end positions if available for safe prompt generation
        if start is not None:
            decision_entry["start"] = start
        if end is not None:
            decision_entry["end"] = end
        
        decisions.append(decision_entry)
    
    return decisions


def _get_reasoning(entity_type: str, decision: Decision, purpose: str) -> str:
    """
    Get a reasoning string for the decision.
    
    Args:
        entity_type: The type of entity (e.g., "PERSON", "EMAIL_ADDRESS")
        decision: The decision made (KEEP, OPTIONAL, REDACT, BLOCK)
        purpose: The user's purpose
    
    Returns:
        A human-readable reason string
    """
    # Try to find a specific template
    key = (entity_type, decision, purpose)
    if key in REASONING_TEMPLATES:
        return REASONING_TEMPLATES[key]
    
    # Try to find a generic template for this entity_type and decision
    key = (entity_type, decision, None)
    if key in REASONING_TEMPLATES:
        return REASONING_TEMPLATES[key]
    
    # Default reasoning
    if decision == "KEEP":
        return f"{entity_type} is kept as it is relevant to the purpose."
    elif decision == "OPTIONAL":
        return f"{entity_type} is optional for this purpose."
    elif decision == "REDACT":
        return f"{entity_type} is redacted for privacy protection."
    elif decision == "BLOCK":
        return f"{entity_type} is blocked due to security concerns."
    else:
        return f"{entity_type} decision: {decision}."

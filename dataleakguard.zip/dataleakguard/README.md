# DataLeakGuard

DataLeakGuard is a purpose-aware privacy firewall that protects users before their prompts are sent to external AI models. It analyzes user prompts for sensitive data, understands the user's intent, and provides intelligent risk assessments to prevent accidental data leaks.

## Current Milestone

This is Milestone 3: Complete Backend with Gemma 4 Purpose Understanding.

**What's implemented:**
- FastAPI backend with REST API
- Sensitive data detection using Microsoft Presidio Analyzer
- Custom recognizers for Aadhaar numbers, API keys, and passwords
- Purpose-aware privacy risk engine
- Safe prompt generator
- Gemma 4 purpose classification integration
- Comprehensive test suite
- Professional frontend interface

**What's NOT implemented yet:**
- External AI API integration
- Database
- Authentication

## Architecture

```
User
↓
DataLeakGuard
↓
Sensitive Data Detection
↓
Gemma 4 Purpose Understanding
↓
Purpose-Aware Privacy Risk Engine
↓
Safe Prompt Generator
↓
Optional External AI
```

## Installation

### Prerequisites
- Python 3.8 or higher
- pip

### Setup

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Install the spaCy English model:
```bash
python -m spacy download en_core_web_sm
```

3. Configure Gemma 4 (optional for purpose understanding):
```bash
cp .env.example .env
# Edit .env and add your GEMMA_API_KEY and GEMMA_BASE_URL
```

## How to Run the Backend

Start the FastAPI server:

```bash
python -m backend.main
```

Or using uvicorn directly:

```bash
uvicorn backend.main:app --reload
```

The server will start on `http://localhost:8000`

## Gemma 4 Purpose Understanding

DataLeakGuard uses Gemma 4 to understand the user's purpose before making privacy decisions. This enables purpose-aware risk assessment.

### Purpose Classification Flow

User prompt → Gemma 4 → Canonical purpose → Risk engine → Privacy decisions

### Supported Purposes

The system classifies prompts into exactly six canonical purposes:

- `resume_improvement` - Improving or refining a resume/CV
- `code_debugging` - Debugging or fixing code issues
- `medical_summarization` - Summarizing medical documents or health records
- `document_analysis` - Analyzing or reviewing documents
- `email_writing` - Writing or composing emails
- `general_question` - General questions or other tasks

### Configuration

Set the following environment variables in `.env`:

```bash
GEMMA_API_KEY=your_api_key_here
GEMMA_MODEL=gemma-4-31b-it
GEMMA_BASE_URL=https://api.provider.com/v1
```

The `GEMMA_API_KEY` is required. `GEMMA_MODEL` defaults to `gemma-4-31b-it` if not specified. `GEMMA_BASE_URL` is required if using a provider with an OpenAI-compatible API.

### Security Considerations

- Gemma's job is ONLY to classify the user's intended task
- Gemma does NOT make privacy decisions
- Privacy decisions are made by the deterministic risk engine
- If Gemma is unavailable, the system falls back to `general_question` with confidence 0.0
- No sensitive information is logged during purpose classification

### FastAPI Integration

The FastAPI integration will call:

```python
from backend.core.gemma import get_classifier

classifier = get_classifier()
result = classifier.classify(prompt)
# result.purpose can be passed to the risk engine
```

## How to Run Tests

Run the test suite:

```bash
pytest
```

Run tests with verbose output:

```bash
pytest -v
```

Run specific test files:

```bash
pytest tests/test_detector.py
pytest tests/test_api.py
```

## API Endpoints

### Health Check

**GET /health**

Check if the service is running.

**Response:**
```json
{
  "status": "ok",
  "service": "DataLeakGuard"
}
```

### Scan Prompt

**POST /api/scan**

Analyze a prompt for sensitive data.

**Request:**
```json
{
  "prompt": "My email is test@example.com"
}
```

**Response:**
```json
{
  "detected": [
    {
      "entity_type": "EMAIL_ADDRESS",
      "value": "test@example.com",
      "start": 15,
      "end": 33,
      "score": 0.95,
      "risk": "MEDIUM"
    }
  ],
  "risk_score": 40,
  "analysis_stage": "sensitive_data_detection"
}
```

**Detected Entity Types:**
- `EMAIL_ADDRESS` - Email addresses
- `PHONE_NUMBER` - Phone numbers
- `CREDIT_CARD` - Credit card numbers
- `PERSON` - Person names
- `AADHAAR_NUMBER` - Indian Aadhaar numbers (custom recognizer)
- `API_KEY` - API keys and tokens (custom recognizer)
- `PASSWORD` - Passwords in context (custom recognizer)

**Risk Levels:**
- `LOW` - Low risk (e.g., person names)
- `MEDIUM` - Medium risk (e.g., email addresses)
- `HIGH` - High risk (e.g., phone numbers)
- `CRITICAL` - Critical risk (e.g., credit cards, Aadhaar, API keys, passwords)

## Current Limitations

1. **No External AI Integration**: The system does not yet send prompts to external AI models. Safe prompts are generated but not automatically forwarded.

2. **Purpose Understanding Dependency**: Purpose-aware risk assessment requires Gemma 4. If Gemma is unavailable, the system falls back to conservative general classification.

3. **No Authentication**: The system does not have user authentication or authorization.

4. **No Database**: All processing is stateless and in-memory.

5. **False Positives**: Custom recognizers may produce false positives, especially for:
   - Plain 12-digit numbers (may be flagged as Aadhaar)
   - Random alphanumeric strings (may be flagged as API keys)
   - Contextual password patterns

## Purpose-Aware Privacy Engine

DataLeakGuard's key innovation is that it doesn't just detect sensitive data - it understands WHY you're using AI and makes context-aware privacy decisions.

**Example:**
- For **resume improvement**: Your name is kept (relevant), but your phone number is redacted (not needed)
- For **code debugging**: Contact information is redacted (not relevant to the bug)
- For **medical summarization**: Contact details are redacted (not needed for summarization)

This is implemented through:
1. Gemma 4 classifies the user's purpose
2. The risk engine applies purpose-specific rules
3. Sensitive data is kept, marked optional, or redacted based on relevance

## Security Note

**Important**: 
- The sensitive data detector and risk engine analyze text locally and do NOT send user prompts to external AI models
- Gemma 4 purpose classification uses an external API, but only for task classification (not privacy decisions)
- If Gemma is unavailable, the system safely falls back to `general_question` classification
- All sensitive data is logged only as entity types, not actual values
- API keys are loaded from environment variables and never committed to version control

## Testing

The project includes comprehensive tests for:

**Sensitive Data Detection:**
- Email detection
- Phone number detection
- Aadhaar number detection
- Credit card detection
- API key detection
- Password detection
- Safe text handling
- Risk scoring

**Purpose Classification:**
- Purpose validation and normalization
- Confidence validation
- Gemma client (mocked)
- Error handling and fallback

**Risk Engine:**
- Purpose-aware privacy decisions
- Risk level mapping
- Multiple entity handling

**Safe Prompt Generation:**
- Entity replacement
- Decision handling
- Position preservation

**API:**
- Health check endpoint
- Scan endpoint

All tests use synthetic data only. No real personal information is used in the test suite.

## Running Tests

Run all tests:
```bash
pytest
```

Run specific test files:
```bash
pytest tests/test_detector.py
pytest tests/test_purpose.py
pytest tests/test_gemma.py
pytest tests/test_risk_engine.py
pytest tests/test_safe_prompt.py
pytest tests/test_api.py
```

Note: Gemma tests use mocks and do not require a real API key.

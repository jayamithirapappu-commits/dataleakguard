import pytest
from backend.core.safe_prompt import generate_safe_prompt


class TestSingleEntityReplacement:
    """Test safe prompt generation with a single entity."""
    
    def test_replace_one_entity_redact(self):
        """Test replacing a single entity with REDACT decision."""
        original = "My phone is 9876543210."
        decisions = [
            {
                "entity_type": "PHONE_NUMBER",
                "value": "9876543210",
                "start": 12,
                "end": 22,
                "decision": "REDACT",
                "reason": "Phone number is sensitive."
            }
        ]
        safe = generate_safe_prompt(original, decisions)
        assert "9876543210" not in safe
        assert "[PHONE_NUMBER REDACTED]" in safe
        assert safe == "My phone is [PHONE_NUMBER REDACTED]."
    
    def test_replace_one_entity_optional(self):
        """Test replacing a single entity with OPTIONAL decision."""
        original = "My email is john@example.com."
        decisions = [
            {
                "entity_type": "EMAIL_ADDRESS",
                "value": "john@example.com",
                "start": 12,
                "end": 28,
                "decision": "OPTIONAL",
                "reason": "Email is optional."
            }
        ]
        safe = generate_safe_prompt(original, decisions)
        assert "john@example.com" not in safe
        assert "[EMAIL_ADDRESS REMOVED - OPTIONAL]" in safe
        assert safe == "My email is [EMAIL_ADDRESS REMOVED - OPTIONAL]."
    
    def test_replace_one_entity_block(self):
        """Test replacing a single entity with BLOCK decision."""
        original = "API key: sk_1234567890abcdef"
        decisions = [
            {
                "entity_type": "API_KEY",
                "value": "sk_1234567890abcdef",
                "start": 9,
                "end": 31,
                "decision": "BLOCK",
                "reason": "API key is blocked."
            }
        ]
        safe = generate_safe_prompt(original, decisions)
        assert "sk_1234567890abcdef" not in safe
        assert "[API_KEY BLOCKED]" in safe
        assert safe == "API key: [API_KEY BLOCKED]"


class TestMultipleEntityReplacement:
    """Test safe prompt generation with multiple entities."""
    
    def test_replace_multiple_entities(self):
        """Test replacing multiple entities in one prompt."""
        original = "Improve my resume. My name is John. My phone is 9876543210 and my Aadhaar is 1234 5678 9012. I know Python and SQL."
        decisions = [
            {
                "entity_type": "PERSON",
                "value": "John",
                "start": 30,
                "end": 34,
                "decision": "KEEP",
                "reason": "Person name is relevant."
            },
            {
                "entity_type": "PHONE_NUMBER",
                "value": "9876543210",
                "start": 49,
                "end": 59,
                "decision": "REDACT",
                "reason": "Phone number is sensitive."
            },
            {
                "entity_type": "AADHAAR_NUMBER",
                "value": "1234 5678 9012",
                "start": 75,
                "end": 89,
                "decision": "REDACT",
                "reason": "Aadhaar is sensitive."
            }
        ]
        safe = generate_safe_prompt(original, decisions)
        
        # John should be kept
        assert "John" in safe
        
        # Phone number should be redacted
        assert "9876543210" not in safe
        assert "[PHONE_NUMBER REDACTED]" in safe
        
        # Aadhaar should be redacted
        assert "1234 5678 9012" not in safe
        assert "[AADHAAR_NUMBER REDACTED]" in safe
        
        # Rest of the prompt should be preserved
        assert "Improve my resume. My name is John." in safe
        assert "I know Python and SQL." in safe
    
    def test_replace_multiple_entities_different_decisions(self):
        """Test multiple entities with different decision types."""
        original = "Contact John at john@example.com or 555-123-4567."
        decisions = [
            {
                "entity_type": "PERSON",
                "value": "John",
                "start": 8,
                "end": 12,
                "decision": "KEEP",
                "reason": "Keep name."
            },
            {
                "entity_type": "EMAIL_ADDRESS",
                "value": "john@example.com",
                "start": 16,
                "end": 32,
                "decision": "OPTIONAL",
                "reason": "Email is optional."
            },
            {
                "entity_type": "PHONE_NUMBER",
                "value": "555-123-4567",
                "start": 36,
                "end": 47,
                "decision": "REDACT",
                "reason": "Phone is sensitive."
            }
        ]
        safe = generate_safe_prompt(original, decisions)
        
        assert "John" in safe
        assert "john@example.com" not in safe
        assert "[EMAIL_ADDRESS REMOVED - OPTIONAL]" in safe
        assert "555-123-4567" not in safe
        assert "[PHONE_NUMBER REDACTED]" in safe


class TestKeepDecision:
    """Test KEEP decision behavior."""
    
    def test_keep_values_unchanged(self):
        """Test that KEEP decision leaves values unchanged."""
        original = "My name is John Doe."
        decisions = [
            {
                "entity_type": "PERSON",
                "value": "John Doe",
                "start": 11,
                "end": 19,
                "decision": "KEEP",
                "reason": "Keep the name."
            }
        ]
        safe = generate_safe_prompt(original, decisions)
        assert safe == original
        assert "John Doe" in safe


class TestEmptyDecisions:
    """Test handling of empty decisions."""
    
    def test_empty_decisions_returns_original(self):
        """Test that empty decisions list returns original prompt unchanged."""
        original = "This is a safe prompt with no sensitive data."
        decisions = []
        safe = generate_safe_prompt(original, decisions)
        assert safe == original
    
    def test_none_decisions_returns_original(self):
        """Test that None decisions returns original prompt unchanged."""
        original = "This is a safe prompt."
        safe = generate_safe_prompt(original, None)
        assert safe == original


class TestSensitiveValueRemoval:
    """Test that sensitive values are completely removed."""
    
    def test_sensitive_values_not_in_safe_prompt(self):
        """Test that sensitive values do not remain in safe prompt after REDACT."""
        original = "My password is abc123 and my API key is sk_secret123."
        decisions = [
            {
                "entity_type": "PASSWORD",
                "value": "abc123",
                "start": 15,
                "end": 21,
                "decision": "REDACT",
                "reason": "Password is sensitive."
            },
            {
                "entity_type": "API_KEY",
                "value": "sk_secret123",
                "start": 39,
                "end": 50,
                "decision": "REDACT",
                "reason": "API key is sensitive."
            }
        ]
        safe = generate_safe_prompt(original, decisions)
        
        # Ensure sensitive values are completely removed
        assert "abc123" not in safe
        assert "sk_secret123" not in safe
        
        # Ensure placeholders are present
        assert "[PASSWORD REDACTED]" in safe
        assert "[API_KEY REDACTED]" in safe


class TestPositionPreservation:
    """Test that entity positions are preserved correctly."""
    
    def test_reverse_order_replacement(self):
        """Test that entities are replaced in reverse order to preserve positions."""
        # This test ensures that replacing later entities doesn't affect earlier positions
        original = "A John B 9876543210 C 123456789012 D"
        decisions = [
            {
                "entity_type": "PERSON",
                "value": "John",
                "start": 2,
                "end": 6,
                "decision": "KEEP",
                "reason": "Keep name."
            },
            {
                "entity_type": "PHONE_NUMBER",
                "value": "9876543210",
                "start": 8,
                "end": 18,
                "decision": "REDACT",
                "reason": "Redact phone."
            },
            {
                "entity_type": "AADHAAR_NUMBER",
                "value": "123456789012",
                "start": 20,
                "end": 32,
                "decision": "REDACT",
                "reason": "Redact Aadhaar."
            }
        ]
        safe = generate_safe_prompt(original, decisions)
        
        # John should be kept at the right position
        assert "John" in safe
        
        # Both numbers should be redacted
        assert "9876543210" not in safe
        assert "123456789012" not in safe
        assert "[PHONE_NUMBER REDACTED]" in safe
        assert "[AADHAAR_NUMBER REDACTED]" in safe
        
        # The structure should be preserved
        assert safe.startswith("A John B")
        assert safe.endswith(" D")


class TestMissingPositions:
    """Test handling when start/end positions are not provided."""
    
    def test_missing_positions_searches_value(self):
        """Test that missing start/end positions triggers value search."""
        original = "My email is test@example.com."
        decisions = [
            {
                "entity_type": "EMAIL_ADDRESS",
                "value": "test@example.com",
                "decision": "REDACT",
                "reason": "Redact email."
                # No start/end provided
            }
        ]
        safe = generate_safe_prompt(original, decisions)
        assert "test@example.com" not in safe
        assert "[EMAIL_ADDRESS REDACTED]" in safe
    
    def test_value_not_found_skips_decision(self):
        """Test that if value is not found, the decision is skipped."""
        original = "This is a prompt."
        decisions = [
            {
                "entity_type": "EMAIL_ADDRESS",
                "value": "notfound@example.com",
                "decision": "REDACT",
                "reason": "Redact email."
            }
        ]
        safe = generate_safe_prompt(original, decisions)
        # Should return original since value not found
        assert safe == original


class TestOverlappingEntities:
    """Test handling of entities that might overlap or be adjacent."""
    
    def test_adjacent_entities(self):
        """Test entities that are adjacent to each other."""
        original = "Call John at 555-123-4567."
        decisions = [
            {
                "entity_type": "PERSON",
                "value": "John",
                "start": 5,
                "end": 9,
                "decision": "KEEP",
                "reason": "Keep name."
            },
            {
                "entity_type": "PHONE_NUMBER",
                "value": "555-123-4567",
                "start": 13,
                "end": 25,
                "decision": "REDACT",
                "reason": "Redact phone."
            }
        ]
        safe = generate_safe_prompt(original, decisions)
        assert "John" in safe
        assert "555-123-4567" not in safe
        assert "[PHONE_NUMBER REDACTED]" in safe


class TestAllDecisionTypes:
    """Test all four decision types in one prompt."""
    
    def test_all_decision_types(self):
        """Test KEEP, OPTIONAL, REDACT, and BLOCK decisions together."""
        original = "John has email john@example.com, password abc123, and API key sk_secret."
        decisions = [
            {
                "entity_type": "PERSON",
                "value": "John",
                "start": 0,
                "end": 4,
                "decision": "KEEP",
                "reason": "Keep name."
            },
            {
                "entity_type": "EMAIL_ADDRESS",
                "value": "john@example.com",
                "start": 14,
                "end": 30,
                "decision": "OPTIONAL",
                "reason": "Optional email."
            },
            {
                "entity_type": "PASSWORD",
                "value": "abc123",
                "start": 40,
                "end": 46,
                "decision": "REDACT",
                "reason": "Redact password."
            },
            {
                "entity_type": "API_KEY",
                "value": "sk_secret",
                "start": 59,
                "end": 68,
                "decision": "BLOCK",
                "reason": "Block API key."
            }
        ]
        safe = generate_safe_prompt(original, decisions)
        
        assert "John" in safe
        assert "john@example.com" not in safe
        assert "[EMAIL_ADDRESS REMOVED - OPTIONAL]" in safe
        assert "abc123" not in safe
        assert "[PASSWORD REDACTED]" in safe
        assert "sk_secret" not in safe
        assert "[API_KEY BLOCKED]" in safe


class TestPromptPreservation:
    """Test that the non-sensitive parts of the prompt are preserved."""
    
    def test_prompt_structure_preserved(self):
        """Test that the overall structure and non-sensitive text is preserved."""
        original = "Dear John, Please review my resume. I have 5 years of experience in Python. Contact me at 555-123-4567."
        decisions = [
            {
                "entity_type": "PERSON",
                "value": "John",
                "start": 5,
                "end": 9,
                "decision": "KEEP",
                "reason": "Keep name."
            },
            {
                "entity_type": "PHONE_NUMBER",
                "value": "555-123-4567",
                "start": 90,
                "end": 102,
                "decision": "REDACT",
                "reason": "Redact phone."
            }
        ]
        safe = generate_safe_prompt(original, decisions)
        
        # Non-sensitive parts should be preserved
        assert "Dear John," in safe
        assert "Please review my resume." in safe
        assert "I have 5 years of experience in Python." in safe
        assert "Contact me at" in safe
        
        # Sensitive part should be redacted
        assert "555-123-4567" not in safe
        assert "[PHONE_NUMBER REDACTED]" in safe

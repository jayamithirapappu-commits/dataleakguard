"""
Tests for Gemma 4 purpose classification client (gemma.py).

These tests use mocks to avoid calling the real Gemma API.
Tests validate:
- Successful classification
- Valid JSON parsing
- Malformed model response handling
- Unknown purpose handling
- Missing confidence handling
- Invalid confidence handling
- API error handling
- Timeout handling
- Fallback behavior
- Configuration error handling
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
from openai import APIError, APITimeoutError, RateLimitError

from backend.core.gemma import GemmaPurposeClassifier, get_classifier
from backend.core.purpose import (
    PurposeResult,
    PURPOSE_RESUME_IMPROVEMENT,
    PURPOSE_CODE_DEBUGGING,
    PURPOSE_MEDICAL_SUMMARIZATION,
    PURPOSE_DOCUMENT_ANALYSIS,
    PURPOSE_EMAIL_WRITING,
    PURPOSE_GENERAL_QUESTION,
)


class TestGemmaInitialization:
    """Test GemmaPurposeClassifier initialization."""
    
    def test_init_with_api_key(self):
        """Test initialization with explicit API key."""
        classifier = GemmaPurposeClassifier(api_key="test_key")
        assert classifier.api_key == "test_key"
        assert classifier.model == "gemma-4-31b-it"  # default
    
    @patch.dict('os.environ', {'GEMMA_API_KEY': 'env_key'})
    def test_init_from_env(self):
        """Test initialization from environment variable."""
        classifier = GemmaPurposeClassifier()
        assert classifier.api_key == "env_key"
    
    @patch.dict('os.environ', {'GEMMA_API_KEY': 'env_key', 'GEMMA_MODEL': 'custom-model'})
    def test_init_custom_model_from_env(self):
        """Test initialization with custom model from environment."""
        classifier = GemmaPurposeClassifier()
        assert classifier.model == "custom-model"
    
    @patch.dict('os.environ', {'GEMMA_API_KEY': 'env_key', 'GEMMA_BASE_URL': 'https://api.example.com'})
    def test_init_custom_base_url_from_env(self):
        """Test initialization with custom base URL from environment."""
        classifier = GemmaPurposeClassifier()
        assert classifier.base_url == "https://api.example.com"
    
    def test_init_missing_api_key(self):
        """Test that initialization fails without API key."""
        with pytest.raises(ValueError, match="GEMMA_API_KEY"):
            GemmaPurposeClassifier(api_key=None)


class TestSuccessfulClassification:
    """Test successful purpose classification with mocked API."""
    
    @patch('backend.core.gemma.OpenAI')
    def test_classify_resume(self, mock_openai):
        """Test successful resume improvement classification."""
        # Mock the OpenAI client and response
        mock_client = MagicMock()
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = '{"purpose": "resume_improvement", "confidence": 0.98}'
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai.return_value = mock_client
        
        classifier = GemmaPurposeClassifier(api_key="test_key")
        result = classifier.classify("Improve my resume.")
        
        assert result.purpose == PURPOSE_RESUME_IMPROVEMENT
        assert result.confidence == 0.98
    
    @patch('backend.core.gemma.OpenAI')
    def test_classify_code_debugging(self, mock_openai):
        """Test successful code debugging classification."""
        mock_client = MagicMock()
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = '{"purpose": "code_debugging", "confidence": 0.97}'
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai.return_value = mock_client
        
        classifier = GemmaPurposeClassifier(api_key="test_key")
        result = classifier.classify("Fix this bug in my code.")
        
        assert result.purpose == PURPOSE_CODE_DEBUGGING
        assert result.confidence == 0.97
    
    @patch('backend.core.gemma.OpenAI')
    def test_classify_medical_summarization(self, mock_openai):
        """Test successful medical summarization classification."""
        mock_client = MagicMock()
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = '{"purpose": "medical_summarization", "confidence": 0.95}'
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai.return_value = mock_client
        
        classifier = GemmaPurposeClassifier(api_key="test_key")
        result = classifier.classify("Summarize this medical document.")
        
        assert result.purpose == PURPOSE_MEDICAL_SUMMARIZATION
        assert result.confidence == 0.95
    
    @patch('backend.core.gemma.OpenAI')
    def test_classify_document_analysis(self, mock_openai):
        """Test successful document analysis classification."""
        mock_client = MagicMock()
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = '{"purpose": "document_analysis", "confidence": 0.96}'
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai.return_value = mock_client
        
        classifier = GemmaPurposeClassifier(api_key="test_key")
        result = classifier.classify("Analyze this contract.")
        
        assert result.purpose == PURPOSE_DOCUMENT_ANALYSIS
        assert result.confidence == 0.96
    
    @patch('backend.core.gemma.OpenAI')
    def test_classify_email_writing(self, mock_openai):
        """Test successful email writing classification."""
        mock_client = MagicMock()
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = '{"purpose": "email_writing", "confidence": 0.98}'
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai.return_value = mock_client
        
        classifier = GemmaPurposeClassifier(api_key="test_key")
        result = classifier.classify("Write an email to my boss.")
        
        assert result.purpose == PURPOSE_EMAIL_WRITING
        assert result.confidence == 0.98
    
    @patch('backend.core.gemma.OpenAI')
    def test_classify_general_question(self, mock_openai):
        """Test successful general question classification."""
        mock_client = MagicMock()
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = '{"purpose": "general_question", "confidence": 0.94}'
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai.return_value = mock_client
        
        classifier = GemmaPurposeClassifier(api_key="test_key")
        result = classifier.classify("What is Python?")
        
        assert result.purpose == PURPOSE_GENERAL_QUESTION
        assert result.confidence == 0.94


class TestMalformedResponseHandling:
    """Test handling of malformed model responses."""
    
    @patch('backend.core.gemma.OpenAI')
    def test_json_with_surrounding_text(self, mock_openai):
        """Test parsing JSON with surrounding text."""
        mock_client = MagicMock()
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = 'Here is the classification: {"purpose": "resume_improvement", "confidence": 0.92}'
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai.return_value = mock_client
        
        classifier = GemmaPurposeClassifier(api_key="test_key")
        result = classifier.classify("Test prompt")
        
        assert result.purpose == PURPOSE_RESUME_IMPROVEMENT
        assert result.confidence == 0.92
    
    @patch('backend.core.gemma.OpenAI')
    def test_json_in_code_fences(self, mock_openai):
        """Test parsing JSON in code fences."""
        mock_client = MagicMock()
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = '```json\n{"purpose": "code_debugging", "confidence": 0.95}\n```'
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai.return_value = mock_client
        
        classifier = GemmaPurposeClassifier(api_key="test_key")
        result = classifier.classify("Test prompt")
        
        assert result.purpose == PURPOSE_CODE_DEBUGGING
        assert result.confidence == 0.95
    
    @patch('backend.core.gemma.OpenAI')
    def test_invalid_json_fallback(self, mock_openai):
        """Test fallback on invalid JSON."""
        mock_client = MagicMock()
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "This is not valid JSON"
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai.return_value = mock_client
        
        classifier = GemmaPurposeClassifier(api_key="test_key")
        result = classifier.classify("Test prompt")
        
        assert result.purpose == PURPOSE_GENERAL_QUESTION
        assert result.confidence == 0.0


class TestUnknownPurposeHandling:
    """Test handling of unknown purpose from model."""
    
    @patch('backend.core.gemma.OpenAI')
    def test_unknownpurpose_normalizes_to_general(self, mock_openai):
        """Test that unknown purpose normalizes to general_question."""
        mock_client = MagicMock()
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = '{"purpose": "unknown_task", "confidence": 0.85}'
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai.return_value = mock_client
        
        classifier = GemmaPurposeClassifier(api_key="test_key")
        result = classifier.classify("Test prompt")
        
        assert result.purpose == PURPOSE_GENERAL_QUESTION
        assert result.confidence == 0.85


class TestConfidenceValidation:
    """Test confidence validation and fallback."""
    
    @patch('backend.core.gemma.OpenAI')
    def test_missing_confidence_fallback(self, mock_openai):
        """Test fallback when confidence is missing."""
        mock_client = MagicMock()
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = '{"purpose": "resume_improvement"}'
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai.return_value = mock_client
        
        classifier = GemmaPurposeClassifier(api_key="test_key")
        result = classifier.classify("Test prompt")
        
        assert result.purpose == PURPOSE_RESUME_IMPROVEMENT
        assert result.confidence == 0.0
    
    @patch('backend.core.gemma.OpenAI')
    def test_confidence_below_zero_clamped(self, mock_openai):
        """Test that confidence below 0 is clamped to 0."""
        mock_client = MagicMock()
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = '{"purpose": "resume_improvement", "confidence": -0.5}'
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai.return_value = mock_client
        
        classifier = GemmaPurposeClassifier(api_key="test_key")
        result = classifier.classify("Test prompt")
        
        assert result.purpose == PURPOSE_RESUME_IMPROVEMENT
        assert result.confidence == 0.0
    
    @patch('backend.core.gemma.OpenAI')
    def test_confidence_above_one_clamped(self, mock_openai):
        """Test that confidence above 1 is clamped to 1."""
        mock_client = MagicMock()
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = '{"purpose": "resume_improvement", "confidence": 1.5}'
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai.return_value = mock_client
        
        classifier = GemmaPurposeClassifier(api_key="test_key")
        result = classifier.classify("Test prompt")
        
        assert result.purpose == PURPOSE_RESUME_IMPROVEMENT
        assert result.confidence == 1.0
    
    @patch('backend.core.gemma.OpenAI')
    def test_invalid_confidence_type_fallback(self, mock_openai):
        """Test fallback when confidence is not numeric."""
        mock_client = MagicMock()
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = '{"purpose": "resume_improvement", "confidence": "high"}'
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai.return_value = mock_client
        
        classifier = GemmaPurposeClassifier(api_key="test_key")
        result = classifier.classify("Test prompt")
        
        assert result.purpose == PURPOSE_RESUME_IMPROVEMENT
        assert result.confidence == 0.0


class TestAPIErrorHandling:
    """Test handling of API errors."""
    
    @patch('backend.core.gemma.OpenAI')
    def test_timeout_error_fallback(self, mock_openai):
        """Test fallback on API timeout."""
        mock_client = MagicMock()
        mock_client.chat.completions.create.side_effect = APITimeoutError("Request timed out")
        mock_openai.return_value = mock_client
        
        classifier = GemmaPurposeClassifier(api_key="test_key")
        result = classifier.classify("Test prompt")
        
        assert result.purpose == PURPOSE_GENERAL_QUESTION
        assert result.confidence == 0.0
    
    @patch('backend.core.gemma.OpenAI')
    def test_rate_limit_error_fallback(self, mock_openai):
        """Test fallback on rate limit error."""
        mock_client = MagicMock()
        mock_client.chat.completions.create.side_effect = RateLimitError("Rate limit exceeded")
        mock_openai.return_value = mock_client
        
        classifier = GemmaPurposeClassifier(api_key="test_key")
        result = classifier.classify("Test prompt")
        
        assert result.purpose == PURPOSE_GENERAL_QUESTION
        assert result.confidence == 0.0
    
    @patch('backend.core.gemma.OpenAI')
    def test_api_error_fallback(self, mock_openai):
        """Test fallback on generic API error."""
        mock_client = MagicMock()
        mock_client.chat.completions.create.side_effect = APIError("API error")
        mock_openai.return_value = mock_client
        
        classifier = GemmaPurposeClassifier(api_key="test_key")
        result = classifier.classify("Test prompt")
        
        assert result.purpose == PURPOSE_GENERAL_QUESTION
        assert result.confidence == 0.0
    
    @patch('backend.core.gemma.OpenAI')
    def test_generic_exception_fallback(self, mock_openai):
        """Test fallback on unexpected exception."""
        mock_client = MagicMock()
        mock_client.chat.completions.create.side_effect = Exception("Unexpected error")
        mock_openai.return_value = mock_client
        
        classifier = GemmaPurposeClassifier(api_key="test_key")
        result = classifier.classify("Test prompt")
        
        assert result.purpose == PURPOSE_GENERAL_QUESTION
        assert result.confidence == 0.0


class TestEmptyInputHandling:
    """Test handling of empty or invalid input."""
    
    @patch('backend.core.gemma.OpenAI')
    def test_empty_prompt_fallback(self, mock_openai):
        """Test fallback on empty prompt."""
        mock_client = MagicMock()
        mock_openai.return_value = mock_client
        
        classifier = GemmaPurposeClassifier(api_key="test_key")
        result = classifier.classify("")
        
        assert result.purpose == PURPOSE_GENERAL_QUESTION
        assert result.confidence == 0.0
    
    @patch('backend.core.gemma.OpenAI')
    def test_none_prompt_fallback(self, mock_openai):
        """Test fallback on None prompt."""
        mock_client = MagicMock()
        mock_openai.return_value = mock_client
        
        classifier = GemmaPurposeClassifier(api_key="test_key")
        result = classifier.classify(None)
        
        assert result.purpose == PURPOSE_GENERAL_QUESTION
        assert result.confidence == 0.0


class TestGetClassifierFactory:
    """Test the get_classifier factory function."""
    
    @patch.dict('os.environ', {'GEMMA_API_KEY': 'test_key'})
    def test_get_classifier_with_env(self):
        """Test factory function with environment variable."""
        classifier = get_classifier()
        assert isinstance(classifier, GemmaPurposeClassifier)
        assert classifier.api_key == "test_key"
    
    def test_get_classifier_missing_env(self):
        """Test factory function without environment variable."""
        with pytest.raises(ValueError, match="GEMMA_API_KEY"):
            get_classifier()


class TestAPILogging:
    """Test that sensitive information is not logged."""
    
    @patch('backend.core.gemma.logger')
    @patch('backend.core.gemma.OpenAI')
    def test_prompt_not_logged(self, mock_openai, mock_logger):
        """Test that the user prompt is not logged."""
        mock_client = MagicMock()
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = '{"purpose": "general_question", "confidence": 0.9}'
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai.return_value = mock_client
        
        classifier = GemmaPurposeClassifier(api_key="test_key")
        result = classifier.classify("My password is secret123")
        
        # Check that the prompt was not logged
        all_logs = [str(call) for call in mock_logger.info.call_args_list]
        assert not any("secret123" in log for log in all_logs)
        assert not any("password" in log for log in all_logs)

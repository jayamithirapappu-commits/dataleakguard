import pytest
from backend.core.risk_engine import evaluate_privacy


class TestResumePurpose:
    """Test privacy decisions for resume_improvement purpose."""
    
    def test_resume_keeps_person(self):
        """Resume purpose should KEEP PERSON entities."""
        entities = [
            {
                "entity_type": "PERSON",
                "value": "John",
                "start": 10,
                "end": 14,
                "score": 0.95,
                "risk": "LOW"
            }
        ]
        decisions = evaluate_privacy(entities, "resume_improvement")
        assert len(decisions) == 1
        assert decisions[0]["entity_type"] == "PERSON"
        assert decisions[0]["decision"] == "KEEP"
        assert decisions[0]["value"] == "John"
    
    def test_resume_redacts_phone_number(self):
        """Resume purpose should REDACT PHONE_NUMBER entities."""
        entities = [
            {
                "entity_type": "PHONE_NUMBER",
                "value": "9876543210",
                "start": 25,
                "end": 35,
                "score": 0.9,
                "risk": "HIGH"
            }
        ]
        decisions = evaluate_privacy(entities, "resume_improvement")
        assert len(decisions) == 1
        assert decisions[0]["entity_type"] == "PHONE_NUMBER"
        assert decisions[0]["decision"] == "REDACT"
    
    def test_resume_redacts_aadhaar(self):
        """Resume purpose should REDACT AADHAAR_NUMBER entities."""
        entities = [
            {
                "entity_type": "AADHAAR_NUMBER",
                "value": "1234 5678 9012",
                "start": 30,
                "end": 44,
                "score": 0.85,
                "risk": "CRITICAL"
            }
        ]
        decisions = evaluate_privacy(entities, "resume_improvement")
        assert len(decisions) == 1
        assert decisions[0]["entity_type"] == "AADHAAR_NUMBER"
        assert decisions[0]["decision"] == "REDACT"
    
    def test_resume_optional_email(self):
        """Resume purpose should mark EMAIL_ADDRESS as OPTIONAL."""
        entities = [
            {
                "entity_type": "EMAIL_ADDRESS",
                "value": "john@example.com",
                "start": 15,
                "end": 31,
                "score": 0.95,
                "risk": "MEDIUM"
            }
        ]
        decisions = evaluate_privacy(entities, "resume_improvement")
        assert len(decisions) == 1
        assert decisions[0]["entity_type"] == "EMAIL_ADDRESS"
        assert decisions[0]["decision"] == "OPTIONAL"


class TestCodeDebuggingPurpose:
    """Test privacy decisions for code_debugging purpose."""
    
    def test_code_debugging_redacts_email(self):
        """Code debugging purpose should REDACT EMAIL_ADDRESS."""
        entities = [
            {
                "entity_type": "EMAIL_ADDRESS",
                "value": "dev@example.com",
                "start": 20,
                "end": 36,
                "score": 0.95,
                "risk": "MEDIUM"
            }
        ]
        decisions = evaluate_privacy(entities, "code_debugging")
        assert len(decisions) == 1
        assert decisions[0]["entity_type"] == "EMAIL_ADDRESS"
        assert decisions[0]["decision"] == "REDACT"
    
    def test_code_debugging_optional_person(self):
        """Code debugging purpose should mark PERSON as OPTIONAL."""
        entities = [
            {
                "entity_type": "PERSON",
                "value": "Alice",
                "start": 10,
                "end": 15,
                "score": 0.9,
                "risk": "LOW"
            }
        ]
        decisions = evaluate_privacy(entities, "code_debugging")
        assert len(decisions) == 1
        assert decisions[0]["entity_type"] == "PERSON"
        assert decisions[0]["decision"] == "OPTIONAL"


class TestAlwaysRedactEntities:
    """Test entities that should always be redacted regardless of purpose."""
    
    def test_credit_card_always_redacted(self):
        """CREDIT_CARD should always be REDACTED."""
        entities = [
            {
                "entity_type": "CREDIT_CARD",
                "value": "4532-1234-5678-9010",
                "start": 15,
                "end": 34,
                "score": 0.95,
                "risk": "CRITICAL"
            }
        ]
        for purpose in ["resume_improvement", "code_debugging", "medical_summarization", "general_question"]:
            decisions = evaluate_privacy(entities, purpose)
            assert len(decisions) == 1
            assert decisions[0]["decision"] == "REDACT"
    
    def test_api_key_always_redacted(self):
        """API_KEY should always be REDACTED."""
        entities = [
            {
                "entity_type": "API_KEY",
                "value": "sk_1234567890abcdef",
                "start": 20,
                "end": 40,
                "score": 0.9,
                "risk": "CRITICAL"
            }
        ]
        for purpose in ["resume_improvement", "code_debugging", "email_writing", "general_question"]:
            decisions = evaluate_privacy(entities, purpose)
            assert len(decisions) == 1
            assert decisions[0]["decision"] == "REDACT"
    
    def test_password_always_redacted(self):
        """PASSWORD should always be REDACTED."""
        entities = [
            {
                "entity_type": "PASSWORD",
                "value": "abc123",
                "start": 10,
                "end": 16,
                "score": 0.85,
                "risk": "CRITICAL"
            }
        ]
        for purpose in ["resume_improvement", "code_debugging", "document_analysis", "general_question"]:
            decisions = evaluate_privacy(entities, purpose)
            assert len(decisions) == 1
            assert decisions[0]["decision"] == "REDACT"


class TestCriticalSafetyRule:
    """Test the CRITICAL safety rule - CRITICAL entities are never KEEP."""
    
    def test_critical_entities_never_keep(self):
        """Entities with CRITICAL risk should never be KEEP."""
        # Even if a rule would normally say KEEP, CRITICAL overrides it
        entities = [
            {
                "entity_type": "PERSON",  # Normally KEEP for resume
                "value": "John",
                "start": 10,
                "end": 14,
                "score": 0.95,
                "risk": "CRITICAL"  # But marked as CRITICAL
            }
        ]
        decisions = evaluate_privacy(entities, "resume_improvement")
        assert len(decisions) == 1
        assert decisions[0]["decision"] == "REDACT"  # Must be REDACT, not KEEP
    
    def test_aadhaar_critical_redacted(self):
        """AADHAAR_NUMBER is CRITICAL and must be REDACTED."""
        entities = [
            {
                "entity_type": "AADHAAR_NUMBER",
                "value": "1234 5678 9012",
                "start": 20,
                "end": 34,
                "score": 0.85,
                "risk": "CRITICAL"
            }
        ]
        decisions = evaluate_privacy(entities, "resume_improvement")
        assert decisions[0]["decision"] == "REDACT"


class TestMultipleEntities:
    """Test handling multiple entities in a single call."""
    
    def test_multiple_entities_different_decisions(self):
        """Test multiple entities with different decisions."""
        entities = [
            {
                "entity_type": "PERSON",
                "value": "John",
                "start": 10,
                "end": 14,
                "score": 0.95,
                "risk": "LOW"
            },
            {
                "entity_type": "EMAIL_ADDRESS",
                "value": "john@example.com",
                "start": 20,
                "end": 36,
                "score": 0.95,
                "risk": "MEDIUM"
            },
            {
                "entity_type": "PHONE_NUMBER",
                "value": "9876543210",
                "start": 40,
                "end": 50,
                "score": 0.9,
                "risk": "HIGH"
            }
        ]
        decisions = evaluate_privacy(entities, "resume_improvement")
        assert len(decisions) == 3
        
        # Check each decision
        person_decision = next(d for d in decisions if d["entity_type"] == "PERSON")
        assert person_decision["decision"] == "KEEP"
        
        email_decision = next(d for d in decisions if d["entity_type"] == "EMAIL_ADDRESS")
        assert email_decision["decision"] == "OPTIONAL"
        
        phone_decision = next(d for d in decisions if d["entity_type"] == "PHONE_NUMBER")
        assert phone_decision["decision"] == "REDACT"


class TestReasoning:
    """Test that reasoning is provided for decisions."""
    
    def test_reasoning_provided(self):
        """Each decision should include a reason."""
        entities = [
            {
                "entity_type": "PERSON",
                "value": "John",
                "start": 10,
                "end": 14,
                "score": 0.95,
                "risk": "LOW"
            }
        ]
        decisions = evaluate_privacy(entities, "resume_improvement")
        assert len(decisions) == 1
        assert "reason" in decisions[0]
        assert len(decisions[0]["reason"]) > 0


class TestUnknownPurpose:
    """Test handling of unknown purposes."""
    
    def test_unknownpurpose_defaults_to_general(self):
        """Unknown purpose should default to general_question rules."""
        entities = [
            {
                "entity_type": "PERSON",
                "value": "John",
                "start": 10,
                "end": 14,
                "score": 0.95,
                "risk": "LOW"
            }
        ]
        decisions = evaluate_privacy(entities, "unknown_purpose")
        assert len(decisions) == 1
        # general_question marks PERSON as OPTIONAL
        assert decisions[0]["decision"] == "OPTIONAL"


class TestUnknownEntityType:
    """Test handling of unknown entity types."""
    
    def test_unknown_entity_redacted_by_default(self):
        """Unknown entity types should be REDACTED by default."""
        entities = [
            {
                "entity_type": "UNKNOWN_TYPE",
                "value": "some_value",
                "start": 10,
                "end": 20,
                "score": 0.8,
                "risk": "MEDIUM"
            }
        ]
        decisions = evaluate_privacy(entities, "resume_improvement")
        assert len(decisions) == 1
        assert decisions[0]["decision"] == "REDACT"


class TestOtherPurposes:
    """Test other supported purposes."""
    
    def test_medical_summarization_decisions(self):
        """Test medical_summarization purpose decisions."""
        entities = [
            {
                "entity_type": "PERSON",
                "value": "Dr. Smith",
                "start": 10,
                "end": 19,
                "score": 0.9,
                "risk": "LOW"
            },
            {
                "entity_type": "EMAIL_ADDRESS",
                "value": "patient@example.com",
                "start": 25,
                "end": 43,
                "score": 0.95,
                "risk": "MEDIUM"
            }
        ]
        decisions = evaluate_privacy(entities, "medical_summarization")
        assert len(decisions) == 2
        
        person_decision = next(d for d in decisions if d["entity_type"] == "PERSON")
        assert person_decision["decision"] == "OPTIONAL"
        
        email_decision = next(d for d in decisions if d["entity_type"] == "EMAIL_ADDRESS")
        assert email_decision["decision"] == "REDACT"
    
    def test_document_analysis_decisions(self):
        """Test document_analysis purpose decisions."""
        entities = [
            {
                "entity_type": "PERSON",
                "value": "Alice",
                "start": 15,
                "end": 20,
                "score": 0.9,
                "risk": "LOW"
            }
        ]
        decisions = evaluate_privacy(entities, "document_analysis")
        assert len(decisions) == 1
        assert decisions[0]["decision"] == "KEEP"
    
    def test_email_writing_decisions(self):
        """Test email_writing purpose decisions."""
        entities = [
            {
                "entity_type": "PERSON",
                "value": "Bob",
                "start": 10,
                "end": 13,
                "score": 0.95,
                "risk": "LOW"
            },
            {
                "entity_type": "EMAIL_ADDRESS",
                "value": "bob@example.com",
                "start": 20,
                "end": 36,
                "score": 0.95,
                "risk": "MEDIUM"
            }
        ]
        decisions = evaluate_privacy(entities, "email_writing")
        assert len(decisions) == 2
        
        person_decision = next(d for d in decisions if d["entity_type"] == "PERSON")
        assert person_decision["decision"] == "KEEP"
        
        email_decision = next(d for d in decisions if d["entity_type"] == "EMAIL_ADDRESS")
        assert email_decision["decision"] == "OPTIONAL"

"""
Tests for purpose classification logic (purpose.py).

These tests validate:
- Purpose constants and enums
- Purpose validation
- Purpose normalization
- Confidence validation
- Structured output (PurposeResult)
- Prompt construction
"""

import pytest
from backend.core.purpose import (
    Purpose,
    PurposeResult,
    PURPOSE_RESUME_IMPROVEMENT,
    PURPOSE_CODE_DEBUGGING,
    PURPOSE_MEDICAL_SUMMARIZATION,
    PURPOSE_DOCUMENT_ANALYSIS,
    PURPOSE_EMAIL_WRITING,
    PURPOSE_GENERAL_QUESTION,
    PURPOSE_FALLBACK,
    SUPPORTED_PURPOSES,
    is_valid_purpose,
    normalize_purpose,
    validate_confidence,
    get_purpose_description,
    construct_classification_prompt,
)


class TestPurposeConstants:
    """Test purpose constants and supported purposes list."""
    
    def test_supported_purposes_count(self):
        """Verify exactly six purposes are supported."""
        assert len(SUPPORTED_PURPOSES) == 6
    
    def test_supported_purposes_content(self):
        """Verify all expected purposes are in the list."""
        assert PURPOSE_RESUME_IMPROVEMENT in SUPPORTED_PURPOSES
        assert PURPOSE_CODE_DEBUGGING in SUPPORTED_PURPOSES
        assert PURPOSE_MEDICAL_SUMMARIZATION in SUPPORTED_PURPOSES
        assert PURPOSE_DOCUMENT_ANALYSIS in SUPPORTED_PURPOSES
        assert PURPOSE_EMAIL_WRITING in SUPPORTED_PURPOSES
        assert PURPOSE_GENERAL_QUESTION in SUPPORTED_PURPOSES
    
    def test_purpose_enum_values(self):
        """Verify Purpose enum has correct values."""
        assert Purpose.RESUME_IMPROVEMENT.value == PURPOSE_RESUME_IMPROVEMENT
        assert Purpose.CODE_DEBUGGING.value == PURPOSE_CODE_DEBUGGING
        assert Purpose.MEDICAL_SUMMARIZATION.value == PURPOSE_MEDICAL_SUMMARIZATION
        assert Purpose.DOCUMENT_ANALYSIS.value == PURPOSE_DOCUMENT_ANALYSIS
        assert Purpose.EMAIL_WRITING.value == PURPOSE_EMAIL_WRITING
        assert Purpose.GENERAL_QUESTION.value == PURPOSE_GENERAL_QUESTION


class TestPurposeValidation:
    """Test purpose validation functions."""
    
    def test_is_valid_purpose_valid(self):
        """Test that valid purposes return True."""
        assert is_valid_purpose(PURPOSE_RESUME_IMPROVEMENT) is True
        assert is_valid_purpose(PURPOSE_CODE_DEBUGGING) is True
        assert is_valid_purpose(PURPOSE_MEDICAL_SUMMARIZATION) is True
        assert is_valid_purpose(PURPOSE_DOCUMENT_ANALYSIS) is True
        assert is_valid_purpose(PURPOSE_EMAIL_WRITING) is True
        assert is_valid_purpose(PURPOSE_GENERAL_QUESTION) is True
    
    def test_is_valid_purpose_invalid(self):
        """Test that invalid purposes return False."""
        assert is_valid_purpose("unknown_purpose") is False
        assert is_valid_purpose("") is False
        assert is_valid_purpose("RESUME") is False  # Case sensitive
        assert is_valid_purpose("invalid") is False
        assert is_valid_purpose(None) is False


class TestPurposeNormalization:
    """Test purpose normalization function."""
    
    def test_normalize_purpose_valid(self):
        """Test that valid purposes are returned unchanged."""
        assert normalize_purpose(PURPOSE_RESUME_IMPROVEMENT) == PURPOSE_RESUME_IMPROVEMENT
        assert normalize_purpose(PURPOSE_CODE_DEBUGGING) == PURPOSE_CODE_DEBUGGING
        assert normalize_purpose(PURPOSE_GENERAL_QUESTION) == PURPOSE_GENERAL_QUESTION
    
    def test_normalize_purpose_case_insensitive(self):
        """Test that normalization handles case correctly."""
        assert normalize_purpose("RESUME_IMPROVEMENT") == PURPOSE_RESUME_IMPROVEMENT
        assert normalize_purpose("Resume_Improvement") == PURPOSE_RESUME_IMPROVEMENT
    
    def test_normalize_purpose_whitespace(self):
        """Test that normalization handles whitespace."""
        assert normalize_purpose("  resume_improvement  ") == PURPOSE_RESUME_IMPROVEMENT
        assert normalize_purpose("\tcode_debugging\n") == PURPOSE_CODE_DEBUGGING
    
    def test_normalize_purpose_unknown(self):
        """Test that unknown purposes fall back to general_question."""
        assert normalize_purpose("unknown") == PURPOSE_GENERAL_QUESTION
        assert normalize_purpose("random") == PURPOSE_GENERAL_QUESTION
        assert normalize_purpose("xyz") == PURPOSE_GENERAL_QUESTION
    
    def test_normalize_purpose_none(self):
        """Test that None falls back to general_question."""
        assert normalize_purpose(None) == PURPOSE_GENERAL_QUESTION
    
    def test_normalize_purpose_empty(self):
        """Test that empty string falls back to general_question."""
        assert normalize_purpose("") == PURPOSE_GENERAL_QUESTION
    
    def test_normalize_purpose_fuzzy_matching(self):
        """Test fuzzy matching for common variations."""
        assert normalize_purpose("resume") == PURPOSE_RESUME_IMPROVEMENT
        assert normalize_purpose("cv") == PURPOSE_RESUME_IMPROVEMENT
        assert normalize_purpose("debug") == PURPOSE_CODE_DEBUGGING
        assert normalize_purpose("debugging") == PURPOSE_CODE_DEBUGGING
        assert normalize_purpose("medical") == PURPOSE_MEDICAL_SUMMARIZATION
        assert normalize_purpose("summarize") == PURPOSE_MEDICAL_SUMMARIZATION
        assert normalize_purpose("document") == PURPOSE_DOCUMENT_ANALYSIS
        assert normalize_purpose("email") == PURPOSE_EMAIL_WRITING
        assert normalize_purpose("general") == PURPOSE_GENERAL_QUESTION


class TestConfidenceValidation:
    """Test confidence validation function."""
    
    def test_validate_confidence_valid(self):
        """Test that valid confidence values return True."""
        assert validate_confidence(0.0) is True
        assert validate_confidence(0.5) is True
        assert validate_confidence(1.0) is True
        assert validate_confidence(0.94) is True
    
    def test_validate_confidence_invalid_low(self):
        """Test that confidence below 0 returns False."""
        assert validate_confidence(-0.1) is False
        assert validate_confidence(-1.0) is False
        assert validate_confidence(-100) is False
    
    def test_validate_confidence_invalid_high(self):
        """Test that confidence above 1 returns False."""
        assert validate_confidence(1.1) is False
        assert validate_confidence(2.0) is False
        assert validate_confidence(100) is False
    
    def test_validate_confidence_invalid_type(self):
        """Test that non-numeric values return False."""
        assert validate_confidence("0.5") is False
        assert validate_confidence(None) is False
        assert validate_confidence([]) is False
        assert validate_confidence({}) is False


class TestPurposeResult:
    """Test PurposeResult dataclass."""
    
    def test_purpose_result_creation(self):
        """Test creating a PurposeResult."""
        result = PurposeResult(purpose="resume_improvement", confidence=0.94)
        assert result.purpose == "resume_improvement"
        assert result.confidence == 0.94
    
    def test_purpose_result_normalization(self):
        """Test that PurposeResult normalizes purpose on creation."""
        result = PurposeResult(purpose="RESUME", confidence=0.9)
        assert result.purpose == "resume_improvement"
    
    def test_purpose_result_confidence_clamp_low(self):
        """Test that PurposeResult clamps confidence below 0 to 0."""
        result = PurposeResult(purpose="general_question", confidence=-0.5)
        assert result.confidence == 0.0
    
    def test_purpose_result_confidence_clamp_high(self):
        """Test that PurposeResult clamps confidence above 1 to 1."""
        result = PurposeResult(purpose="general_question", confidence=1.5)
        assert result.confidence == 1.0
    
    def test_purpose_result_confidence_type_conversion(self):
        """Test that PurposeResult converts confidence to float."""
        result = PurposeResult(purpose="general_question", confidence="0.5")
        assert result.confidence == 0.5
        assert isinstance(result.confidence, float)
    
    def test_purpose_result_invalid_confidence(self):
        """Test that PurposeResult handles invalid confidence."""
        result = PurposeResult(purpose="general_question", confidence="invalid")
        assert result.confidence == 0.0


class TestPurposeDescription:
    """Test get_purpose_description function."""
    
    def test_get_purpose_description_resume(self):
        """Test description for resume_improvement."""
        desc = get_purpose_description(PURPOSE_RESUME_IMPROVEMENT)
        assert "resume" in desc.lower()
    
    def test_get_purpose_description_code_debugging(self):
        """Test description for code_debugging."""
        desc = get_purpose_description(PURPOSE_CODE_DEBUGGING)
        assert "debug" in desc.lower()
    
    def test_get_purpose_description_medical(self):
        """Test description for medical_summarization."""
        desc = get_purpose_description(PURPOSE_MEDICAL_SUMMARIZATION)
        assert "medical" in desc.lower()
    
    def test_get_purpose_description_document(self):
        """Test description for document_analysis."""
        desc = get_purpose_description(PURPOSE_DOCUMENT_ANALYSIS)
        assert "document" in desc.lower()
    
    def test_get_purpose_description_email(self):
        """Test description for email_writing."""
        desc = get_purpose_description(PURPOSE_EMAIL_WRITING)
        assert "email" in desc.lower()
    
    def test_get_purpose_description_general(self):
        """Test description for general_question."""
        desc = get_purpose_description(PURPOSE_GENERAL_QUESTION)
        assert "general" in desc.lower()
    
    def test_get_purpose_description_unknown(self):
        """Test description for unknown purpose."""
        desc = get_purpose_description("unknown")
        assert desc == "Unknown purpose"


class TestPromptConstruction:
    """Test construct_classification_prompt function."""
    
    def test_construct_prompt_includes_system_instruction(self):
        """Test that prompt includes system instruction."""
        prompt = construct_classification_prompt("test prompt")
        assert "purpose-classification component" in prompt
        assert "privacy firewall" in prompt
    
    def test_construct_prompt_includes_purposes(self):
        """Test that prompt includes all supported purposes."""
        prompt = construct_classification_prompt("test prompt")
        for purpose in SUPPORTED_PURPOSES:
            assert purpose in prompt
    
    def test_construct_prompt_includes_examples(self):
        """Test that prompt includes few-shot examples."""
        prompt = construct_classification_prompt("test prompt")
        assert "resume_improvement" in prompt
        assert "code_debugging" in prompt
        assert "medical_summarization" in prompt
    
    def test_construct_prompt_includes_user_prompt(self):
        """Test that prompt includes the user's prompt."""
        user_prompt = "Improve my resume."
        prompt = construct_classification_prompt(user_prompt)
        assert user_prompt in prompt
    
    def test_construct_prompt_includes_rules(self):
        """Test that prompt includes classification rules."""
        prompt = construct_classification_prompt("test prompt")
        assert "DO NOT make privacy decisions" in prompt
        assert "confidence" in prompt.lower()

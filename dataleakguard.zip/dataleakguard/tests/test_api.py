import pytest
from fastapi.testclient import TestClient
from backend.main import app


@pytest.fixture
def client():
    """Fixture to create a test client for FastAPI."""
    return TestClient(app)


class TestHealthEndpoint:
    """Test the /health endpoint."""
    
    def test_health_check(self, client):
        response = client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "ok"
        assert data["service"] == "DataLeakGuard"


class TestScanEndpoint:
    """Test the /api/scan endpoint."""
    
    def test_scan_with_email(self, client):
        request_data = {"prompt": "My email is test@example.com"}
        response = client.post("/api/scan", json=request_data)
        assert response.status_code == 200
        data = response.json()
        assert "detected" in data
        assert "risk_score" in data
        assert data["analysis_stage"] == "sensitive_data_detection"
        assert len(data["detected"]) > 0
        assert any(d["entity_type"] == "EMAIL_ADDRESS" for d in data["detected"])
    
    def test_scan_safe_text(self, client):
        request_data = {"prompt": "Hello, how are you?"}
        response = client.post("/api/scan", json=request_data)
        assert response.status_code == 200
        data = response.json()
        assert "detected" in data
        assert "risk_score" in data
        assert data["analysis_stage"] == "sensitive_data_detection"
        # May detect PERSON names but should have low/no critical risk
    
    def test_scan_empty_prompt(self, client):
        request_data = {"prompt": ""}
        response = client.post("/api/scan", json=request_data)
        assert response.status_code == 200
        data = response.json()
        assert data["detected"] == []
        assert data["risk_score"] == 0
        assert data["analysis_stage"] == "sensitive_data_detection"
    
    def test_scan_with_password(self, client):
        request_data = {"prompt": "password=abc123"}
        response = client.post("/api/scan", json=request_data)
        assert response.status_code == 200
        data = response.json()
        assert len(data["detected"]) > 0
        assert any(d["entity_type"] == "PASSWORD" for d in data["detected"])
    
    def test_scan_with_aadhaar(self, client):
        request_data = {"prompt": "My Aadhaar is 1234 5678 9012"}
        response = client.post("/api/scan", json=request_data)
        assert response.status_code == 200
        data = response.json()
        assert len(data["detected"]) > 0
        assert any(d["entity_type"] == "AADHAAR_NUMBER" for d in data["detected"])
    
    def test_scan_with_api_key(self, client):
        request_data = {"prompt": "api_key=sk_1234567890abcdef1234567890abcdef"}
        response = client.post("/api/scan", json=request_data)
        assert response.status_code == 200
        data = response.json()
        assert len(data["detected"]) > 0
        assert any(d["entity_type"] == "API_KEY" for d in data["detected"])
    
    def test_scan_multiple_entities(self, client):
        request_data = {"prompt": "Email: test@example.com, Phone: 555-123-4567"}
        response = client.post("/api/scan", json=request_data)
        assert response.status_code == 200
        data = response.json()
        assert len(data["detected"]) >= 1
        assert data["risk_score"] > 0
    
    def test_scan_response_structure(self, client):
        request_data = {"prompt": "test@example.com"}
        response = client.post("/api/scan", json=request_data)
        assert response.status_code == 200
        data = response.json()
        
        # Check response structure
        assert "detected" in data
        assert isinstance(data["detected"], list)
        assert "risk_score" in data
        assert isinstance(data["risk_score"], int)
        assert "analysis_stage" in data
        assert data["analysis_stage"] == "sensitive_data_detection"
        
        # Check detected entity structure if present
        if data["detected"]:
            entity = data["detected"][0]
            assert "entity_type" in entity
            assert "value" in entity
            assert "start" in entity
            assert "end" in entity
            assert "score" in entity
            assert "risk" in entity

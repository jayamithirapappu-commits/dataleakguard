// DOM Elements
const purposeSelect = document.getElementById('purpose');
const promptInput = document.getElementById('prompt');
const scanBtn = document.getElementById('scanBtn');
const initialState = document.getElementById('initialState');
const resultsState = document.getElementById('resultsState');
const riskLevel = document.getElementById('riskLevel');
const riskScore = document.getElementById('riskScore');
const riskBar = document.getElementById('riskBar');
const detectionsList = document.getElementById('detectionsList');
const explanationText = document.getElementById('explanationText');
const safePromptSection = document.getElementById('safePromptSection');
const safePrompt = document.getElementById('safePrompt');
const copyBtn = document.getElementById('copyBtn');
const resetBtn = document.getElementById('resetBtn');

// State
let currentScanResult = null;
let currentPurpose = 'resume_improvement';

// MOCK IMPLEMENTATION FOR NOW
// This will be replaced with real API call in future
async function scanPrompt() {
    const userPrompt = promptInput.value.trim();
    
    if (!userPrompt) {
        alert('Please enter a prompt to scan.');
        return null;
    }

    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 700));

    // Mock response based on the specification
    const mockResponse = {
        risk_score: 85,
        risk_level: 'HIGH',
        detected: [
            {
                entity_type: 'PERSON',
                value: 'Priya',
                risk: 'LOW',
                decision: 'KEEP',
                start: 24,
                end: 29
            },
            {
                entity_type: 'EMAIL_ADDRESS',
                value: 'priya@example.com',
                risk: 'MEDIUM',
                decision: 'OPTIONAL',
                start: 40,
                end: 56
            },
            {
                entity_type: 'PHONE_NUMBER',
                value: '9876543210',
                risk: 'HIGH',
                decision: 'REDACT',
                start: 73,
                end: 83
            },
            {
                entity_type: 'AADHAAR_NUMBER',
                value: '1234 5678 9012',
                risk: 'CRITICAL',
                decision: 'REDACT',
                start: 102,
                end: 116
            }
        ]
    };

    return mockResponse;
}

// MOCK IMPLEMENTATION FOR NOW
// This will be replaced with real API call in future
function generateSafePrompt(originalPrompt, decisions) {
    let safePrompt = originalPrompt;
    
    // Sort decisions by start position in reverse order to preserve positions
    const sortedDecisions = [...decisions].sort((a, b) => b.start - a.start);
    
    for (const decision of sortedDecisions) {
        if (decision.decision === 'KEEP') {
            continue;
        }
        
        const replacement = getReplacement(decision.entity_type, decision.decision);
        safePrompt = safePrompt.substring(0, decision.start) + 
                     replacement + 
                     safePrompt.substring(decision.end);
    }
    
    return safePrompt;
}

function getReplacement(entityType, decision) {
    if (decision === 'OPTIONAL') {
        return `[${entityType} OPTIONAL]`;
    } else if (decision === 'REDACT') {
        return `[${entityType} REDACTED]`;
    } else if (decision === 'BLOCK') {
        return `[${entityType} BLOCKED]`;
    }
    return `[${entityType} ${decision}]`;
}

function getRiskBadgeClass(risk) {
    switch (risk) {
        case 'LOW':
            return 'risk-low';
        case 'MEDIUM':
            return 'risk-medium';
        case 'HIGH':
            return 'risk-high';
        case 'CRITICAL':
            return 'risk-critical';
        default:
            return 'risk-medium';
    }
}

function getDecisionBadgeClass(decision) {
    switch (decision) {
        case 'KEEP':
            return 'decision-keep';
        case 'OPTIONAL':
            return 'decision-optional';
        case 'REDACT':
            return 'decision-redact';
        case 'BLOCK':
            return 'decision-block';
        default:
            return 'decision-redact';
    }
}

function getExplanation(purpose) {
    const explanations = {
        'resume_improvement': 'For resume improvement, your name is useful, but your phone number and government identification number are not required. DataLeakGuard recommends removing unnecessary sensitive information before sending the prompt to an AI model.',
        'code_debugging': 'For code debugging, personal information like names and contact details are not needed. DataLeakGuard recommends removing them to protect your privacy.',
        'medical_summarization': 'For medical document summarization, contact information is not necessary. DataLeakGuard redacts it to protect your privacy.',
        'document_analysis': 'For document analysis, phone numbers and government IDs are typically not needed and are redacted for privacy protection.',
        'email_writing': 'For email composition, phone numbers and government IDs are not required and are redacted for privacy protection.',
        'general_question': 'For general questions, sensitive personal information is not needed and is redacted to protect your privacy.'
    };
    
    return explanations[purpose] || explanations['general_question'];
}

function getEntityDisplayName(entityType) {
    const displayNames = {
        'PERSON': 'PERSON',
        'EMAIL_ADDRESS': 'EMAIL',
        'PHONE_NUMBER': 'PHONE',
        'CREDIT_CARD': 'CARD',
        'AADHAAR_NUMBER': 'AADHAAR',
        'API_KEY': 'API KEY',
        'PASSWORD': 'PASSWORD'
    };
    
    return displayNames[entityType] || entityType;
}

function getRiskColorClass(riskLevel) {
    switch (riskLevel) {
        case 'LOW':
            return '#81c784';
        case 'MEDIUM':
            return '#ffd54f';
        case 'HIGH':
            return '#ffb74d';
        case 'CRITICAL':
            return '#ef5350';
        default:
            return '#ffd54f';
    }
}

function displayResults(result) {
    currentScanResult = result;
    
    // Update risk level
    riskLevel.textContent = result.risk_level;
    riskLevel.style.color = getRiskColorClass(result.risk_level);
    
    // Update risk score
    riskScore.textContent = result.risk_score;
    riskScore.style.color = getRiskColorClass(result.risk_level);
    
    // Animate risk bar
    setTimeout(() => {
        riskBar.style.width = `${result.risk_score}%`;
    }, 100);
    
    // Clear previous detections
    detectionsList.innerHTML = '';
    
    // Add entities to table with sequential animation
    result.detected.forEach((entity, index) => {
        const row = document.createElement('div');
        row.className = 'table-row';
        row.style.animationDelay = `${index * 0.1}s`;
        
        const entityTypeCell = document.createElement('div');
        entityTypeCell.className = 'table-cell';
        // IMPORTANT: Display entity type only, NOT the sensitive value
        entityTypeCell.textContent = getEntityDisplayName(entity.entity_type);
        
        const riskCell = document.createElement('div');
        riskCell.className = 'table-cell';
        const riskBadge = document.createElement('span');
        riskBadge.className = `risk-badge ${getRiskBadgeClass(entity.risk)}`;
        riskBadge.textContent = entity.risk;
        riskCell.appendChild(riskBadge);
        
        const decisionCell = document.createElement('div');
        decisionCell.className = 'table-cell';
        const decisionBadge = document.createElement('span');
        decisionBadge.className = `decision-badge ${getDecisionBadgeClass(entity.decision)}`;
        decisionBadge.textContent = entity.decision;
        decisionCell.appendChild(decisionBadge);
        
        row.appendChild(entityTypeCell);
        row.appendChild(riskCell);
        row.appendChild(decisionCell);
        
        detectionsList.appendChild(row);
    });
    
    // Update explanation
    explanationText.textContent = getExplanation(currentPurpose);
    
    // Show results state, hide initial state
    initialState.classList.add('hidden');
    resultsState.classList.remove('hidden');
    
    // Hide safe prompt section if visible
    safePromptSection.classList.add('hidden');
}

// Event Listeners
scanBtn.addEventListener('click', async () => {
    // Disable button during scan
    scanBtn.disabled = true;
    scanBtn.innerHTML = '<span class="btn-icon">⏳</span><span class="btn-text">ANALYZING...</span>';
    
    try {
        const result = await scanPrompt();
        if (result) {
            displayResults(result);
        }
    } catch (error) {
        console.error('Scan failed:', error);
        alert('Failed to scan prompt. Please try again.');
    } finally {
        // Re-enable button
        scanBtn.disabled = false;
        scanBtn.innerHTML = '<span class="btn-icon">🔍</span><span class="btn-text">SCAN PROMPT</span>';
    }
});

// Auto-generate safe prompt after results are displayed
const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
        if (mutation.target === resultsState && !resultsState.classList.contains('hidden')) {
            // Results are now visible, generate safe prompt
            if (currentScanResult) {
                const originalPrompt = promptInput.value;
                const decisionsWithPositions = currentScanResult.detected.map(entity => ({
                    entity_type: entity.entity_type,
                    decision: entity.decision,
                    start: entity.start,
                    end: entity.end
                }));
                
                const safe = generateSafePrompt(originalPrompt, decisionsWithPositions);
                safePrompt.value = safe;
                
                // Show safe prompt section with animation
                setTimeout(() => {
                    safePromptSection.classList.remove('hidden');
                    // Scroll to safe prompt
                    safePromptSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }, 500);
            }
        }
    });
});

observer.observe(resultsState, { attributes: true, attributeFilter: ['class'] });

copyBtn.addEventListener('click', async () => {
    try {
        await navigator.clipboard.writeText(safePrompt.value);
        const originalText = copyBtn.innerHTML;
        copyBtn.innerHTML = '<span class="btn-icon">✓</span><span class="btn-text">COPIED</span>';
        
        setTimeout(() => {
            copyBtn.innerHTML = originalText;
        }, 2000);
    } catch (error) {
        console.error('Failed to copy:', error);
        alert('Failed to copy to clipboard. Please copy manually.');
    }
});

resetBtn.addEventListener('click', () => {
    // Reset prompt input to exact default for mock to work
    promptInput.value = 'Improve my resume. My name is Priya. My email is priya@example.com. My phone number is 9876543210. My Aadhaar number is 1234 5678 9012. I have experience with Python and SQL.';
    
    // Reset purpose
    purposeSelect.value = 'resume_improvement';
    currentPurpose = 'resume_improvement';
    
    // Hide results and safe prompt sections
    resultsState.classList.add('hidden');
    safePromptSection.classList.add('hidden');
    
    // Show initial state
    initialState.classList.remove('hidden');
    
    // Reset risk bar
    riskBar.style.width = '0%';
    
    // Reset state
    currentScanResult = null;
    
    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
});

purposeSelect.addEventListener('change', (e) => {
    currentPurpose = e.target.value;
    
    // If results are already displayed, update explanation
    if (currentScanResult) {
        explanationText.textContent = getExplanation(currentPurpose);
    }
});

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    currentPurpose = purposeSelect.value;
});
